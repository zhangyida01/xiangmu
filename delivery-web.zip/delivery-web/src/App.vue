<template>
  <router-view />
</template>